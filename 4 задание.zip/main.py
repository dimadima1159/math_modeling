a=[1,5,'Good','Bad']
b=[9,'Blue','Red',11]
print(a[1]+b[3])
print(a[2]+b[2])
print(a[0]*b[0])
print(a[1]**b[3])
c=a+b
print(c)