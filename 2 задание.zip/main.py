print(type('Hello,World!'))
print(type(3+4))
print(type(3/4))
print(type([1,2,5,10,100]))
