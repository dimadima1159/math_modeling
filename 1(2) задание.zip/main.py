a=int(input('Введите a:'))
b=2
if a%b==0:
  print('число', a,'- чётное')
else:
  print('число', a,'- нечётное') 